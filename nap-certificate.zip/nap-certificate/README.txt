1. Create a new GitHub repo and upload everything in this folder (keep .github).
2. Open Actions > Build APK > Run workflow.
3. Download "NAP-Certificate-Generation-Tool-apk" -> app-debug.apk and install on Android.
